package org.testleaf.testcases;

import org.testleaf.baseAPI.ProjectSpecificMethods;
import org.testleaf.pages.LoginPage;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC001_LoginLogout extends ProjectSpecificMethods {
	@BeforeTest
	public void setData() {
		excelFileName="Login";
	}
	@Test(dataProvider="fetchData")
	public void loginLogout(String uName, String pwd) {
		
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickLogout();
				
		/*LoginPage obj = new LoginPage();
		obj.enterUserName();
		obj.enterPassword();
		obj.clickLogin();*/
				
				
				
				
				
				
				
				
				
				
				
				
				
		
	}
	
	
}
